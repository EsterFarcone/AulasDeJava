package com.senai.hotelaria;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {


     Hotel hotel = new Hotel ( "Tris", "São Paulo");
        hotel.exibirInformacoes();

     Quarto quarto1 = new Quarto ( 220, "Luxo");
     Quarto quarto2 = new Quarto ( 221, "Simples");
     Quarto quarto3 = new Quarto ( 223, "Simples");
     Quarto quarto4 = new Quarto ( 224, "Luxo");
     Quarto quarto5 = new Quarto ( 225, "Familia");
     Quarto quarto6 = new Quarto ( 226, "Familia");


        hotel.adicionarQuarto(quarto1);
        hotel.adicionarQuarto(quarto2);
        hotel.adicionarQuarto(quarto3);
        hotel.adicionarQuarto(quarto4);
        hotel.adicionarQuarto(quarto5);
        hotel.adicionarQuarto(quarto6);

        Cliente cliente1 = new Cliente ("Sabrina", "233432134", "saberinantoni@gmailcom");
        Cliente cliente2 = new Cliente ("Laura", "233459293934", "lauranantoni@gmailcom");
        Cliente cliente3 = new Cliente ("Marcos", "4777258105", "marcosantoni@gmailcom");
        Cliente cliente4 = new Cliente ("Felipe", "4755189325", "Felipemarques@gmailcom");

        Reserva reserva = new Reserva(cliente2, quarto5, LocalDate.now(),
                LocalDate.now().plusDays(5));
        reserva.adicionarQuarto(quarto2);
        reserva.adicionarCliente(cliente3);

        Funcionario funcionario1 = new Funcionario("Claudia", "Recepcionista");
        Funcionario funcionario2 = new Funcionario("Ana Clara", "Recepcionista");
        Funcionario funcionario3 = new Funcionario("Marcos", "Recepcionista");
        Funcionario funcionario4 = new Funcionario("Lucas", "Recepcionista");
        Funcionario funcionario5 = new Funcionario("Maia", "Recepcionista");
        Funcionario funcionario6 = new Funcionario("Maria Lima", "Auxiliar De Limpeza");
        Funcionario funcionario7 = new Funcionario("Gabriel", "Auxiliar De Limpeza");
        Funcionario funcionario8 = new Funcionario("Murilo", "Auxiliar De Limpeza");
        Funcionario funcionario9 = new Funcionario("Maisa", "Camarera");


        Servico servico = new Servico("Auxiliar De Limpeza", 100.0);
        Servico servico = new Servico("Recepcionista", 150.0);
        Servico servico = new Servico("Camareira", 100.0);

        hotel.exibirInformacoes();
    }
}
